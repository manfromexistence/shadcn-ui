import { Button } from "@/registry/default/ui/button"

export function ButtonSecondary() {
  return <Button variant="secondary">Secondary</Button>
}
