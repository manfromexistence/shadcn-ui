import { Badge } from "@/registry/default/ui/badge"

export function BadgeDemo() {
  return <Badge>Badge</Badge>
}
