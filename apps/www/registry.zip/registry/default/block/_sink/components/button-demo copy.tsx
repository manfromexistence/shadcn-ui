import { Button } from "@/registry/default/ui/button"

export function ButtonDemo() {
  return <Button>Button</Button>
}
