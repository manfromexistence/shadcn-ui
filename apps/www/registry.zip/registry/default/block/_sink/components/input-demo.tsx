import { Input } from "@/registry/default/ui/input"

export function InputDemo() {
  return <Input type="email" placeholder="Email" />
}
