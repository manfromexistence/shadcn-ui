import { Button } from "@/registry/default/ui/button"

export function ButtonDestructive() {
  return <Button variant="destructive">Destructive</Button>
}
