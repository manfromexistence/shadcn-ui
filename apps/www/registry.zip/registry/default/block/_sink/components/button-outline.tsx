import { Button } from "@/registry/default/ui/button"

export function ButtonOutline() {
  return <Button variant="outline">Outline</Button>
}
