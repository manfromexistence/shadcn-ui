import { Badge } from "@/registry/default/ui/badge"

export function BadgeOutline() {
  return <Badge variant="outline">Outline</Badge>
}
