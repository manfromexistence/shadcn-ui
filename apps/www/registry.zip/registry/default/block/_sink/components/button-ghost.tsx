import { Button } from "@/registry/default/ui/button"

export function ButtonGhost() {
  return <Button variant="ghost">Ghost</Button>
}
