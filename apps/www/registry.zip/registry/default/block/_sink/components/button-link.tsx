import { Button } from "@/registry/default/ui/button"

export function ButtonLink() {
  return <Button variant="link">Link</Button>
}
