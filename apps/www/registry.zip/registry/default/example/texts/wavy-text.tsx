import { WavyText } from "@/registry/default/ui/text"

export default function WavyTextDemo() {
  return (
    <div className="flex items-center space-x-2">
      <WavyText />
    </div>
  )
}
