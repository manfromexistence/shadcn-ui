import { BlurIn } from "@/registry/default/ui/text"

export default function BlurInDemo() {
  return (
    <div className="flex items-center space-x-2">
      <BlurIn />
    </div>
  )
}
