import { SlightFlip } from "@/registry/default/ui/text"

export default function SlightFlipDemo() {
  return (
    <div className="flex items-center space-x-2">
      <SlightFlip />
    </div>
  )
}
