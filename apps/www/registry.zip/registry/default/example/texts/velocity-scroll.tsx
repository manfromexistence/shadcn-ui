import { VelocityScroll } from "@/registry/default/ui/text"

export default function VelocityScrollDemo() {
  return (
    <div className="flex items-center space-x-2">
      <VelocityScroll />
    </div>
  )
}
