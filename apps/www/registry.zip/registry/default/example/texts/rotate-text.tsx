import { RotateText } from "@/registry/default/ui/text"

export default function RotateTextDemo() {
  return (
    <div className="flex items-center space-x-2">
      <RotateText />
    </div>
  )
}
