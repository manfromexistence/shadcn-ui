import { LetterPullUp } from "@/registry/default/ui/text"

export default function LetterPullUpDemo() {
  return (
    <div className="flex items-center space-x-2">
      <LetterPullUp />
    </div>
  )
}
