import { WordPullUp } from "@/registry/default/ui/text"

export default function WordPullUpDemo() {
  return (
    <div className="flex items-center space-x-2">
      <WordPullUp />
    </div>
  )
}
