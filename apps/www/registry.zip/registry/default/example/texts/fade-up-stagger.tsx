import { FadeUpStagger } from "@/registry/default/ui/text"

export default function FadeUpStaggerDemo() {
  return (
    <div className="flex items-center space-x-2">
      <FadeUpStagger key={0} />
    </div>
  )
}
