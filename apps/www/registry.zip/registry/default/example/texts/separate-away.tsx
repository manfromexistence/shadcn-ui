import { SeparateAway } from "@/registry/default/ui/text"

export default function SeparateAwayDemo() {
  return (
    <div className="flex items-center space-x-2">
      <SeparateAway />
    </div>
  )
}
