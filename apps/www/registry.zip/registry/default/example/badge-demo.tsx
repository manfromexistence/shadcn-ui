import { Badge } from "@/registry/default/ui/badge"

export default function BadgeDemo() {
  return <Badge>Badge</Badge>
}
