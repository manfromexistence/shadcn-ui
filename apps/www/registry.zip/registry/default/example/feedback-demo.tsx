import { Feedback } from "@/registry/default/ui/feedback"

export default function FeedbackDemo() {
  return (
    <div className="flex items-center space-x-2">
      <Feedback />
    </div>
  )
}
