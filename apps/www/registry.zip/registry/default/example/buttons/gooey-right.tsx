import { Button } from "@/registry/default/ui/buttons"

export default function ButtonGooeyRight() {
  return <Button variant="gooeyRight">Gooey Right</Button>
}
