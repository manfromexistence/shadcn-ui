import { Button } from "@/registry/default/ui/buttons"

export default function ButtonLinkHover2() {
  return <Button variant="linkHover2">Link Hover 2</Button>
}
