import { Button } from "@/registry/default/ui/buttons"

export default function ButtonGooeyLeft() {
  return <Button variant="gooeyLeft">Gooey left</Button>
}
