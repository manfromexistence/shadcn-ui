import { Button } from "@/registry/default/ui/buttons"

export default function ButtonLinkHover1() {
  return <Button variant="linkHover1">Link Hover 1</Button>
}
