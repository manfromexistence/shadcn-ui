import { Button } from "@/registry/default/ui/buttons"

export default function ButtonShine() {
  return <Button variant="shine">Shine</Button>
}
