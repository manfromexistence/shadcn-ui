import { Button } from "@/registry/default/ui/buttons"

export default function ButtonRingHover() {
  return <Button variant="ringHover">Ring Hover</Button>
}
